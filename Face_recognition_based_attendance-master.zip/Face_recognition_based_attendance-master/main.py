import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mess
import tkinter.simpledialog as tsd
import cv2
import os
import csv
import numpy as np
from PIL import Image
import pandas as pd
import datetime
import time
import hashlib # For password hashing

# --- CONFIGURATION ---
HAARCASCADE_FILE = "haarcascade_frontalface_default.xml"
STUDENT_DETAILS_DIR = "StudentDetails"
TRAINING_IMAGE_DIR = "TrainingImage"
TRAINING_LABEL_DIR = "TrainingImageLabel"
ATTENDANCE_DIR = "Attendance"
TRAINER_FILE = os.path.join(TRAINING_LABEL_DIR, "Trainner.yml")
PASSWORD_FILE = os.path.join(TRAINING_LABEL_DIR, "psd.txt")
DETAILS_FILE = os.path.join(STUDENT_DETAILS_DIR, "StudentDetails.csv")
MIN_SAMPLES = 1 # Increased samples for better training
CONFIDENCE_THRESHOLD = 75 # Increased threshold for better accuracy (lower value is better match)

# ---------------------------------------------------------------------- Utility Functions

def assure_path_exists(path):
    """Creates a directory if it doesn't exist."""
    if not os.path.exists(path):
        os.makedirs(path)

def tick():
    """Updates the clock in the GUI."""
    time_string = time.strftime('%H:%M:%S')
    clock.config(text=time_string)
    clock.after(200, tick)

def check_haarcascadefile():
    """Checks for the face detection cascade file."""
    if not os.path.isfile(HAARCASCADE_FILE):
        mess.showerror(title='Some file missing', message=f'Please ensure "{HAARCASCADE_FILE}" is in the directory.')
        window.destroy()

# ---------------------------------------------------------------------- Security Functions (Password)

def hash_password(password):
    """Hashes a password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(stored_hash, entered_password):
    """Verifies an entered password against a stored hash."""
    return stored_hash == hash_password(entered_password)

def save_pass():
    """Handles password setting and changing with hashing."""
    assure_path_exists(TRAINING_LABEL_DIR)

    # 1. Handle first-time password setup
    if not os.path.isfile(PASSWORD_FILE):
        master.destroy()
        new_pas = tsd.askstring('Old Password not found', 'Please enter a new password below', show='*')
        if new_pas:
            with open(PASSWORD_FILE, "w") as tf:
                tf.write(hash_password(new_pas))
            mess.showinfo(title='Password Registered', message='New password was registered successfully!!')
        else:
            mess.showwarning(title='No Password Entered', message='Password not set!! Please try again')
        return

    # 2. Handle password change request
    with open(PASSWORD_FILE, "r") as tf:
        key_hash = tf.read().strip()

    op = old.get()
    newp = new.get()
    nnewp = nnew.get()
    
    if verify_password(key_hash, op):
        if newp and newp == nnewp:
            with open(PASSWORD_FILE, "w") as tf:
                tf.write(hash_password(newp))
            mess.showinfo(title='Password Changed', message='Password changed successfully!!')
            master.destroy()
        elif not newp:
            mess.showerror(title='Error', message='New password cannot be empty!')
        else:
            mess.showerror(title='Error', message='Confirm new password again!!!')
    else:
        mess.showerror(title='Wrong Password', message='Please enter correct old password.')

def change_pass():
    """Opens the Change Password window."""
    global master, old, new, nnew
    master = tk.Tk()
    master.geometry("400x160")
    master.resizable(False, False)
    master.title("Change Password")
    master.configure(background="white")
    
    tk.Label(master, text='Enter Old Password', bg='white', font=('times', 12, 'bold')).place(x=10, y=10)
    old = tk.Entry(master, width=25, fg="black", relief='solid', font=('times', 12, 'bold'), show='*')
    old.place(x=180, y=10)
    tk.Label(master, text='Enter New Password', bg='white', font=('times', 12, 'bold')).place(x=10, y=45)
    new = tk.Entry(master, width=25, fg="black", relief='solid', font=('times', 12, 'bold'), show='*')
    new.place(x=180, y=45)
    tk.Label(master, text='Confirm New Password', bg='white', font=('times', 12, 'bold')).place(x=10, y=80)
    nnew = tk.Entry(master, width=25, fg="black", relief='solid', font=('times', 12, 'bold'), show='*')
    nnew.place(x=180, y=80)
    
    tk.Button(master, text="Cancel", command=master.destroy, fg="black", bg="red", height=1, width=25, activebackground="white", font=('times', 10, 'bold')).place(x=200, y=120)
    tk.Button(master, text="Save", command=save_pass, fg="black", bg="#3ece48", height=1, width=25, activebackground="white", font=('times', 10, 'bold')).place(x=10, y=120)
    master.mainloop()

def psw():
    """Password protection gate for the Training function."""
    assure_path_exists(TRAINING_LABEL_DIR)
    key_hash = ''
    
    # 1. Handle first-time password setup
    if not os.path.isfile(PASSWORD_FILE):
        new_pas = tsd.askstring('Old Password not found', 'Please enter a new password below', show='*')
        if new_pas:
            with open(PASSWORD_FILE, "w") as tf:
                tf.write(hash_password(new_pas))
            mess.showinfo(title='Password Registered', message='New password was registered successfully!!')
        else:
            mess.showwarning(title='No Password Entered', message='Password not set!! Please try again')
        return

    # 2. Get stored hash
    with open(PASSWORD_FILE, "r") as tf:
        key_hash = tf.read().strip()
    
    # 3. Ask for password and verify
    password = tsd.askstring('Password', 'Enter Password', show='*')
    if password is None:
        pass
    elif verify_password(key_hash, password):
        TrainImages()
    else:
        mess.showerror(title='Wrong Password', message='You have entered wrong password')

# ---------------------------------------------------------------------- Registration and Training

def clear():
    """Clears the ID entry field."""
    txt.delete(0, 'end')
    message1.configure(text=f"1)Take Images ({MIN_SAMPLES} required) >>> 2)Save Profile")

def clear2():
    """Clears the Name entry field."""
    txt2.delete(0, 'end')
    message1.configure(text=f"1)Take Images ({MIN_SAMPLES} required) >>> 2)Save Profile")

def TakeImages():
    """Captures images for training a new student profile."""
    check_haarcascadefile()
    assure_path_exists(STUDENT_DETAILS_DIR)
    assure_path_exists(TRAINING_IMAGE_DIR)

    Id = txt.get()
    name = txt2.get()
    
    if not Id or not name:
        mess.showerror(title='Error', message='ID and Name cannot be empty.')
        return
    
    if not name.replace(" ", "").isalpha():
        mess.showerror(title='Error', message='Name should contain only alphabetic characters.')
        return
    
    if not Id.isdigit():
        mess.showerror(title='Error', message='ID should be a number.')
        return

    # Determine the next serial number
    serial = 0
    if os.path.isfile(DETAILS_FILE):
        df_students = pd.read_csv(DETAILS_FILE, header=None, skiprows=1)
        if not df_students.empty:
            serial = df_students[0].max() + 1
        else:
            serial = 1
    else:
        # Create CSV file with header if it doesn't exist
        with open(DETAILS_FILE, 'a+', newline='') as csvFile1:
            writer = csv.writer(csvFile1)
            writer.writerow(['SERIAL NO.', '', 'ID', '', 'NAME'])
        serial = 1

    cam = cv2.VideoCapture(0)
    detector = cv2.CascadeClassifier(HAARCASCADE_FILE)
    sampleNum = 0
    
    while True:
        ret, img = cam.read()
        if not ret:
            mess.showerror(title='Webcam Error', message='Could not read frame from webcam.')
            break
            
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)
        
        for (x, y, w, h) in faces:
            sampleNum += 1
            # Save the captured face image
            cv2.imwrite(os.path.join(TRAINING_IMAGE_DIR, f"{name}.{serial}.{Id}.{sampleNum}.jpg"), gray[y:y+h, x:x+w])
            cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(img, f"Sample: {sampleNum}/{MIN_SAMPLES}", (x, y + h + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.imshow('Taking Images', img)
            
        if cv2.waitKey(100) & 0xFF == ord('q') or sampleNum >= MIN_SAMPLES:
            break
            
    cam.release()
    cv2.destroyAllWindows()
    
    if sampleNum >= MIN_SAMPLES:
        # Save details to CSV
        with open(DETAILS_FILE, 'a+', newline='') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow([serial, '', Id, '', name])
        message1.configure(text=f"Images Taken for ID : {Id} (Now click 'Save Profile')")
    else:
        # If not enough images were taken, clean up the taken images and don't register
        for file in os.listdir(TRAINING_IMAGE_DIR):
            if file.startswith(f"{name}.{serial}.{Id}"):
                os.remove(os.path.join(TRAINING_IMAGE_DIR, file))
        message1.configure(text="Image capture failed. Not enough faces detected.")


def getImagesAndLabels(path):
    """Loads face images and their corresponding labels (IDs) for training."""
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    IDs = []
    for imagePath in imagePaths:
        try:
            pilImage = Image.open(imagePath).convert('L') # Convert to grayscale
            imageNp = np.array(pilImage, 'uint8')
            # Extract ID from filename (part 2 of the split)
            # Filename format: [name].[serial_no].[id].[sample_no].jpg
            ID = int(os.path.split(imagePath)[-1].split(".")[1])
            faces.append(imageNp)
            IDs.append(ID)
        except Exception as e:
            print(f"Error loading image {imagePath}: {e}")
            
    return faces, IDs

def TrainImages():
    """Trains the face recognition model."""
    check_haarcascadefile()
    assure_path_exists(TRAINING_LABEL_DIR)
    
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces, IDs = getImagesAndLabels(TRAINING_IMAGE_DIR)
    
    if not IDs:
        mess.showerror(title='No Registrations', message='No images found for training! Please register someone first.')
        return
        
    try:
        recognizer.train(faces, np.array(IDs))
    except Exception as e:
        mess.showerror(title='Training Error', message=f'Error during training: {e}')
        return
        
    recognizer.save(TRAINER_FILE)
    message1.configure(text="Profile Saved Successfully")
    message.configure(text=f'Total Registrations till now: {len(set(IDs))}')

# ---------------------------------------------------------------------- Attendance Tracking

def TrackImages():
    """Tracks recognized faces and records attendance."""
    check_haarcascadefile()
    assure_path_exists(ATTENDANCE_DIR)
    assure_path_exists(STUDENT_DETAILS_DIR)
    
    for k in tv.get_children(): # Clear previous attendance log
        tv.delete(k)
        
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    
    if not os.path.isfile(TRAINER_FILE):
        mess.showerror(title='Data Missing', message='Trained model (Trainner.yml) missing. Please save a profile first!')
        return

    recognizer.read(TRAINER_FILE)
    faceCascade = cv2.CascadeClassifier(HAARCASCADE_FILE)

    if not os.path.isfile(DETAILS_FILE):
        mess.showerror(title='Details Missing', message='Students details (StudentDetails.csv) are missing, please check!')
        return
        
    try:
        df = pd.read_csv(DETAILS_FILE)
    except Exception as e:
        mess.showerror(title='CSV Error', message=f'Error reading student details: {e}')
        return

    cam = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_SIMPLEX
    col_names = ['Id', '', 'Name', '', 'Date', '', 'Time']
    attendance_records = {} # Use a dictionary to store unique attendance per session

    while True:
        ret, im = cam.read()
        if not ret:
            break
            
        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, 1.2, 5)
        
        for (x, y, w, h) in faces:
            cv2.rectangle(im, (x, y), (x + w, y + h), (225, 0, 0), 2)
            serial, conf = recognizer.predict(gray[y:y + h, x:x + w])
            
            if conf < CONFIDENCE_THRESHOLD:
                # Recognized
                ts = time.time()
                date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                
                # Fetch Name and ID using the Serial No.
                row_data = df.loc[df['SERIAL NO.'] == serial]
                if not row_data.empty:
                    student_name = row_data['NAME'].values[0]
                    student_id = row_data['ID'].values[0]
                    display_name = student_name
                    
                    if student_id not in attendance_records:
                        attendance_records[student_id] = [str(student_id), '', student_name, '', str(date), '', str(timeStamp)]
                else:
                    display_name = 'Unknown'
            else:
                # Not Recognized
                display_name = 'Unknown'
                
            cv2.putText(im, str(display_name), (x, y + h + 30), font, 1, (255, 255, 255), 2)
            cv2.putText(im, f"Conf: {round(conf)}", (x, y + h + 60), font, 0.7, (0, 255, 255), 2)
            
        cv2.imshow('Taking Attendance (Press "q" to stop)', im)
        if cv2.waitKey(20) == ord('q'):
            break
            
    cam.release()
    cv2.destroyAllWindows()

    # Write unique attendance records to today's CSV file
    if attendance_records:
        ts = time.time()
        date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
        attendance_file = os.path.join(ATTENDANCE_DIR, "Attendance_" + date + ".csv")
        
        exists = os.path.isfile(attendance_file)
        
        with open(attendance_file, 'a+', newline='') as csvFile1:
            writer = csv.writer(csvFile1)
            if not exists:
                writer.writerow(col_names)
            
            # Write unique records
            for record in attendance_records.values():
                writer.writerow(record)
                
    # Update Treeview with today's attendance log
    if os.path.isfile(attendance_file):
        with open(attendance_file, 'r') as csvFile1:
            reader1 = csv.reader(csvFile1)
            next(reader1) # Skip header
            
            # Read unique entries and insert into Treeview
            seen_ids = set()
            for lines in reader1:
                if len(lines) >= 7 and lines[0] not in seen_ids:
                    iidd = lines[0] + '    '
                    tv.insert('', 0, text=iidd, values=(lines[2], lines[4], lines[6]))
                    seen_ids.add(lines[0])

# ---------------------------------------------------------------------- Used Stuffs (GUI Setup)

ts = time.time()
date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
day, month, year = date.split("-")

mont = {'01': 'January', '02': 'February', '03': 'March', '04': 'April', '05': 'May', '06': 'June', '07': 'July', '08': 'August', '09': 'September', '10': 'October', '11': 'November', '12': 'December'}

window = tk.Tk()
window.geometry("1280x720")
window.resizable(True, False)
window.title("Face Recognition Based Attendance System")
window.configure(background='#262523')

# --- Frames ---
frame1 = tk.Frame(window, bg="#00aeff")
frame1.place(relx=0.11, rely=0.17, relwidth=0.39, relheight=0.80)

frame2 = tk.Frame(window, bg="#00aeff")
frame2.place(relx=0.51, rely=0.17, relwidth=0.38, relheight=0.80)

# --- Header & Clock ---
message3 = tk.Label(window, text="Face Recognition Based Attendance System", fg="white", bg="#262523", width=55, height=1, font=('times', 29, ' bold '))
message3.place(x=10, y=10)

frame3 = tk.Frame(window, bg="#c4c6ce")
frame3.place(relx=0.52, rely=0.09, relwidth=0.09, relheight=0.07)

frame4 = tk.Frame(window, bg="#c4c6ce")
frame4.place(relx=0.36, rely=0.09, relwidth=0.16, relheight=0.07)

datef = tk.Label(frame4, text=day + "-" + mont[month] + "-" + year + " | ", fg="orange", bg="#262523", width=55, height=1, font=('times', 22, ' bold '))
datef.pack(fill='both', expand=1)

clock = tk.Label(frame3, fg="orange", bg="#262523", width=55, height=1, font=('times', 22, ' bold '))
clock.pack(fill='both', expand=1)
tick()

# --- Frame 2 (Registration) Labels and Entries ---
head2 = tk.Label(frame2, text="For New Registrations", fg="black", bg="#3ece48", width=38, font=('times', 17, ' bold '))
head2.grid(row=0, column=0, pady=5)

lbl = tk.Label(frame2, text="Enter ID", width=20, height=1, fg="black", bg="#00aeff", font=('times', 17, ' bold '))
lbl.place(x=80, y=55)

txt = tk.Entry(frame2, width=32, fg="black", font=('times', 15, ' bold '))
txt.place(x=30, y=88)

lbl2 = tk.Label(frame2, text="Enter Name", width=20, fg="black", bg="#00aeff", font=('times', 17, ' bold '))
lbl2.place(x=80, y=140)

txt2 = tk.Entry(frame2, width=32, fg="black", font=('times', 15, ' bold '))
txt2.place(x=30, y=173)

message1 = tk.Label(frame2, text=f"1)Take Images ({MIN_SAMPLES} required) >>> 2)Save Profile", bg="#00aeff", fg="black", width=39, height=1, activebackground="yellow", font=('times', 15, ' bold '))
message1.place(x=7, y=230)

message = tk.Label(frame2, text="", bg="#00aeff", fg="black", width=39, height=1, activebackground="yellow", font=('times', 16, ' bold '))
message.place(x=7, y=450)

# --- Frame 1 (Attendance) Labels ---
head1 = tk.Label(frame1, text="For Already Registered", fg="black", bg="#3ece48", width=38, font=('times', 17, ' bold '))
head1.place(x=0, y=0)

lbl3 = tk.Label(frame1, text="Attendance Log", width=20, fg="black", bg="#00aeff", height=1, font=('times', 17, ' bold '))
lbl3.place(x=100, y=115)

# --- Registration Count ---
res = 0
if os.path.isfile(DETAILS_FILE):
    df_students = pd.read_csv(DETAILS_FILE)
    res = len(df_students)
message.configure(text=f'Total Registrations till now: {res}')

# --- Menu Bar ---
menubar = tk.Menu(window, relief='ridge')
filemenu = tk.Menu(menubar, tearoff=0)
filemenu.add_command(label='Change Password', command=change_pass)
filemenu.add_command(label='Exit', command=window.destroy)
menubar.add_cascade(label='Help', font=('times', 29, ' bold '), menu=filemenu)

# --- Treeview Attendance Table ---
tv = ttk.Treeview(frame1, height=13, columns=('name', 'date', 'time'))
tv.column('#0', width=82, anchor='w')
tv.column('name', width=130, anchor='w')
tv.column('date', width=133, anchor='center')
tv.column('time', width=133, anchor='center')
tv.grid(row=2, column=0, padx=(0, 0), pady=(150, 0), columnspan=4, sticky='nsew')
tv.heading('#0', text='ID')
tv.heading('name', text='NAME')
tv.heading('date', text='DATE')
tv.heading('time', text='TIME')

# --- Scrollbar ---
scroll = ttk.Scrollbar(frame1, orient='vertical', command=tv.yview)
scroll.grid(row=2, column=4, padx=(0, 100), pady=(150, 0), sticky='ns')
tv.configure(yscrollcommand=scroll.set)

# --- Buttons ---
clearButton = tk.Button(frame2, text="Clear", command=clear, fg="black", bg="#ea2a2a", width=11, activebackground="white", font=('times', 11, ' bold '))
clearButton.place(x=335, y=86)
clearButton2 = tk.Button(frame2, text="Clear", command=clear2, fg="black", bg="#ea2a2a", width=11, activebackground="white", font=('times', 11, ' bold '))
clearButton2.place(x=335, y=172)

takeImg = tk.Button(frame2, text="Take Images", command=TakeImages, fg="white", bg="blue", width=34, height=1, activebackground="white", font=('times', 15, ' bold '))
takeImg.place(x=30, y=300)

trainImg = tk.Button(frame2, text="Save Profile", command=psw, fg="white", bg="blue", width=34, height=1, activebackground="white", font=('times', 15, ' bold '))
trainImg.place(x=30, y=380)

trackImg = tk.Button(frame1, text="Take Attendance", command=TrackImages, fg="black", bg="yellow", width=35, height=1, activebackground="white", font=('times', 15, ' bold '))
trackImg.place(x=30, y=50)

quitWindow = tk.Button(frame1, text="Quit", command=window.destroy, fg="black", bg="red", width=35, height=1, activebackground="white", font=('times', 15, ' bold '))
quitWindow.place(x=30, y=450)

# -------------------------------------------------------------------------------------- End

window.configure(menu=menubar)
window.mainloop()
